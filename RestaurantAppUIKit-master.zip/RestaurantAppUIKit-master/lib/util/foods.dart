List<Map> foods = [
  {
    "img": "assets/food1.jpeg",
    "name": "Fruit Salad"
  },
  {
    "img": "assets/food2.jpeg",
    "name": "Fruit Salad"
  },
  {
    "img": "assets/food3.jpeg",
    "name": "Hamburger"
  },
  {
    "img": "assets/food4.jpeg",
    "name": "Fruit Salad"
  },
  {
    "img": "assets/food5.jpeg",
    "name": "Hamburger"
  },
  {
    "img": "assets/food6.jpeg",
    "name": "Steak"
  },
  {
    "img": "assets/food7.jpeg",
    "name": "Pizza"
  },
  {
    "img": "assets/food8.jpeg",
    "name": "Asparagus"
  },
  {
    "img": "assets/food9.jpeg",
    "name": "Salad"
  },
  {
    "img": "assets/food10.jpeg",
    "name": "Pizza"
  },
  {
    "img": "assets/food11.jpeg",
    "name": "Pizza"
  },
  {
    "img": "assets/food12.jpg",
    "name": "Salad"
  },
];